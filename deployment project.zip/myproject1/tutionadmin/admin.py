from django.contrib import admin

# Register your models here.
from .models import AddCourse,MainAdminRegister
# Register your models here.
admin.site.register(AddCourse)
admin.site.register(MainAdminRegister)
