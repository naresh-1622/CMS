from django.apps import AppConfig


class TutionadminConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'tutionadmin'
